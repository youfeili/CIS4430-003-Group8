//
//  myappApp.swift
//  myapp
//
//  Created by mikaya on 11/15/22.
//

import SwiftUI

@main
struct myappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
