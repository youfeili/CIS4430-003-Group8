//
//  ContentView.swift
//  myapp
//
//  Created by Kai Guo and Youfei Li on 11/15/22.
//

import SwiftUI
import CoreMotion



struct ContentView: View {
    
    private let pedometer: CMPedometer = CMPedometer()
    
    @State private var steps: Int?
    @State private var distance: Double?
    @State private var distance2: Double?
    
    private var isPedomterAvailable: Bool{
        return CMPedometer.isPedometerEventTrackingAvailable() && CMPedometer.isDistanceAvailable() && CMPedometer.isStepCountingAvailable()
    }
   
    private func updateUI(data: CMPedometerData){
        steps = data.numberOfSteps.intValue
        
        guard let pedometerDistance = data.distance else {return}
        let distanceInMeters = Measurement(value:  pedometerDistance.doubleValue, unit: UnitLength.meters)
        distance = data.distance?.doubleValue
        distance2 = distanceInMeters.converted(to: .miles).value
    }
    
    private func initializePedometer(){
        if isPedomterAvailable{
            
            guard let startDate = Calendar.current.date(byAdding: .day,value: -7, to: Date()) else {
                return
            }
            
            pedometer.queryPedometerData(from: startDate, to: Date()){ (data, error) in
                
                guard let data = data, error == nil else {return}
                
                
                updateUI(data: data)
                
                
            }
        }
    }
    var body: some View{
        Text(steps != nil ? "\(steps!) step you have walked this week" : "").padding()
        Text(distance2 != nil ? String(format: "%.2f miles you have walked", distance2!): "").padding()
        Text(distance != nil ? String(format: "%.2f meter you have walked", distance!): "").padding()
        
            .onAppear{
                initializePedometer()
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
